﻿<#
 MAM Agent (PowerShell) - cho Windows 7/8/8.1/10/11 và Windows Server 2008 R2 trở lên.
 Cài:   powershell -ExecutionPolicy Bypass -File MAM-Agent.ps1 -Install -Server http://192.168.1.10:7070
 Gỡ:    powershell -ExecutionPolicy Bypass -File "C:\Program Files\MAM Agent\MAM-Agent.ps1" -Uninstall
 Chạy PowerShell 2.0 (có sẵn trên Windows 7), không cần cài thêm gì.
#>
param([switch]$Install, [switch]$Uninstall, [switch]$Run, [string]$Server = '', [string]$Key = '', [string]$Name = '', [string]$Lang = '')

try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$Version = '1.1.0'
$ScriptPath = $MyInvocation.MyCommand.Path
$Dir = Join-Path $env:ProgramFiles 'MAM Agent'
$CfgPath = Join-Path $Dir 'config.json'
$LogPath = Join-Path $Dir 'agent.log'
$ErrorActionPreference = 'Continue'

# MAM · thư viện PowerShell dùng chung (chạy được từ PowerShell 2.0 trên Windows 7)
function ConvertTo-MamJson($v) {
  if ($v -eq $null) { return 'null' }
  if ($v -is [string]) { $s = (($v -replace '\\','\\' -replace '"','\"') -replace '[\x00-\x1f]',' '); return '"' + [regex]::Replace($s, '[^\x00-\x7e]', { param($m) '\u' + ([int][char]$m.Value).ToString('x4') }) + '"' }  # ASCII + \uXXXX: không phụ thuộc bảng mã đầu ra
  if ($v -is [bool]) { if ($v) { return 'true' } else { return 'false' } }
  if ($v -is [int] -or $v -is [long] -or $v -is [double] -or $v -is [decimal] -or $v -is [single] -or $v -is [uint32] -or $v -is [uint64] -or $v -is [int16] -or $v -is [uint16] -or $v -is [byte]) {
    return [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0}', $v)
  }
  if ($v -is [System.Collections.IDictionary]) {
    $p = @(); foreach ($k in $v.Keys) { $p += ('"' + $k + '":' + (ConvertTo-MamJson $v[$k])) }
    return '{' + ($p -join ',') + '}'
  }
  if ($v -is [System.Collections.IEnumerable]) {
    $p = @(); foreach ($i in $v) { $p += (ConvertTo-MamJson $i) }
    return '[' + ($p -join ',') + ']'
  }
  return ConvertTo-MamJson ([string]$v)
}

function Get-MamTemp {
  try {
    $t = @(Get-WmiObject -Namespace 'root\wmi' -Class MSAcpi_ThermalZoneTemperature -ErrorAction Stop)
    # Vùng nào ra số không thể có ở máy đang chạy (dưới 20°C hoặc trên 110°C) là BIOS khai báo rác, bỏ.
    $max = $null
    foreach ($z in $t) { $c = ($z.CurrentTemperature / 10) - 273.15; if ($c -ge 20 -and $c -le 110 -and ($max -eq $null -or $c -gt $max)) { $max = $c } }
    if ($max -ne $null) { return [math]::Round($max, 1) }
  } catch { }
  return $null
}

function Get-MamHw {
  $os = Get-WmiObject Win32_OperatingSystem
  $cs = Get-WmiObject Win32_ComputerSystem
  $cpu = @(Get-WmiObject Win32_Processor)
  $gpu = @(Get-WmiObject Win32_VideoController)
  $bd = Get-WmiObject Win32_BaseBoard
  $bios = Get-WmiObject Win32_BIOS
  $fail = $false
  try { foreach ($x in @(Get-WmiObject -Namespace 'root\wmi' -Class MSStorageDriver_FailurePredictStatus -ErrorAction Stop)) { if ($x.PredictFailure) { $fail = $true } } } catch { }
  $disks = @()
  foreach ($d in @(Get-WmiObject Win32_DiskDrive)) {
    $disks += @{ model = [string]$d.Model; sizeGB = [math]::Round($d.Size / 1GB, 0); type = [string]$d.MediaType; health = [string]$d.Status; tempC = $null; wear = $null; hours = $null; serial = ([string]$d.SerialNumber).Trim(); pnp = ([string]$d.PNPDeviceID) }
  }
  try {
    if (Get-Command Get-PhysicalDisk -ErrorAction SilentlyContinue) {
      # Ghép theo số sê-ri (hoặc tên), KHÔNG theo thứ tự: thứ tự Win32_DiskDrive và Get-PhysicalDisk có thể ngược nhau,
      # ghép theo thứ tự thì SSD bị ghi thành HDD và ngược lại. Không khớp được thì để nguyên, không đoán.
      $pds = @(Get-PhysicalDisk)
      for ($i = 0; $i -lt $disks.Count; $i++) {
        $sn = [string]$disks[$i].serial
        $pd = $null
        if ($sn) { $pd = @($pds | Where-Object { ([string]$_.SerialNumber).Trim() -eq $sn })[0] }
        if (-not $pd) { $pd = @($pds | Where-Object { ([string]$_.FriendlyName).Trim() -eq ([string]$disks[$i].model).Trim() })[0] }
        if (-not $pd) { continue }
        $disks[$i].health = [string]$pd.HealthStatus; $disks[$i].type = [string]$pd.MediaType
        try { $rc = $pd | Get-StorageReliabilityCounter -ErrorAction Stop
          $disks[$i].tempC = $rc.Temperature; $disks[$i].wear = $rc.Wear; $disks[$i].hours = $rc.PowerOnHours } catch { }
      }
    }
  } catch { }
  # Chỉ số S.M.A.R.T thật của ổ: Windows chỉ báo Unhealthy khi ổ gần chết, SSD mòn 63% vẫn ra Healthy và Wear = 0.
  # Ghép theo PNPDeviceID (InstanceName của WMI = PNPDeviceID + '_0'), chắc hơn ghép theo số sê-ri.
  try {
    $sd = @{}; $sf = @{}
    try { foreach ($x in @(Get-WmiObject -Namespace 'root\wmi' -Class MSStorageDriver_FailurePredictData -ErrorAction Stop)) { $sd[([string]$x.InstanceName).ToUpper()] = $x.VendorSpecific } } catch { }
    try { foreach ($x in @(Get-WmiObject -Namespace 'root\wmi' -Class MSStorageDriver_FailurePredictStatus -ErrorAction Stop)) { $sf[([string]$x.InstanceName).ToUpper()] = [bool]$x.PredictFailure } } catch { }
    for ($i = 0; $i -lt $disks.Count; $i++) {
      $key = ([string]$disks[$i].pnp).ToUpper() + '_0'
      $b = $sd[$key]
      if ($sf.ContainsKey($key)) { $disks[$i].predictFail = $sf[$key] }
      if (-not $b) { continue }
      $at = @{}; $va = @{}
      for ($j = 2; $j + 11 -lt $b.Count; $j += 12) {
        $id = [int]$b[$j]
        if ($id -eq 0) { continue }
        $raw = [int64]$b[$j + 5] + [int64]$b[$j + 6] * 256 + [int64]$b[$j + 7] * 65536 + [int64]$b[$j + 8] * 16777216
        $at[$id] = $raw; $va[$id] = [int]$b[$j + 3]
      }
      $disks[$i].smart = $true
      if ($at.ContainsKey(9)) { $disks[$i].hours = [int64]$at[9] }
      if ($at.ContainsKey(194)) { $disks[$i].tempC = [int]([int64]$at[194] -band 255) }
      foreach ($m in @(@(5, 'realloc'), @(197, 'pending'), @(198, 'offline'), @(187, 'uncorrect'))) {
        if ($at.ContainsKey($m[0])) { $disks[$i][$m[1]] = [int64]$at[$m[0]] }
      }
      # % sức khỏe: mỗi chỉ số SMART có giá trị chuẩn hóa 100 = như mới, tụt dần khi ổ yếu.
      # Lấy giá trị thấp nhất trong các chỉ số về lỗi và tuổi thọ; bỏ giá trị 0 hoặc >100 (ổ không hỗ trợ).
      $hp = $null
      foreach ($id in 5, 10, 177, 187, 196, 197, 198, 231) {
        if ($va.ContainsKey($id) -and $va[$id] -ge 1 -and $va[$id] -le 100 -and ($hp -eq $null -or $va[$id] -lt $hp)) { $hp = $va[$id] }
      }
      if ($hp -ne $null) { $disks[$i].healthPct = $hp }
      # Tuổi thọ SSD còn lại: chỉ số E7 (231) hoặc B1 (177); HDD không có, để trống chứ không đoán.
      if (([string]$disks[$i].type) -match 'SSD') {
        foreach ($id in 231, 177) {
          if ($va.ContainsKey($id) -and $va[$id] -ge 0 -and $va[$id] -le 100) { $disks[$i].lifeLeft = $va[$id]; break }
        }
      }
    }
  } catch { }
  # Loại RAM (DDR3/DDR4/DDR5) để Kiểm kê hiện rõ; Windows 7 không có SMBIOSMemoryType thì dùng MemoryType
  $ramType = ''
  $ramSticks = 0
  $ramSlots = 0
  try {
    $mt = @{ 20 = 'DDR'; 21 = 'DDR2'; 24 = 'DDR3'; 26 = 'DDR4'; 34 = 'DDR5' }
    $ts = @()
    $mems = @(Get-WmiObject Win32_PhysicalMemory)
    $ramSticks = $mems.Count
    # Tổng số khe của bo mạch; máy ảo hoặc BIOS khai thiếu thì để 0, Console chỉ hiện số thanh
    try { foreach ($a in @(Get-WmiObject Win32_PhysicalMemoryArray)) { $ramSlots += [int]$a.MemoryDevices } } catch { }
    if ($ramSlots -lt $ramSticks) { $ramSlots = 0 }
    foreach ($m in $mems) {
      $k = 0
      try { $k = [int]$m.SMBIOSMemoryType } catch { }
      if (-not $mt[$k]) { try { $k = [int]$m.MemoryType } catch { } }
      if ($mt[$k] -and $ts -notcontains $mt[$k]) { $ts += $mt[$k] }
    }
    $ramType = ($ts -join '/')
  } catch { }
  $macs = @(); $ips = @()
  foreach ($n in @(Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled })) {
    if ($n.MACAddress) { $macs += [string]$n.MACAddress }
    foreach ($ip in @($n.IPAddress)) { if ($ip -and $ip -notmatch ':') { $ips += [string]$ip } }
  }
  $cores = 0; $threads = 0
  foreach ($c in $cpu) { $cores += [int]$c.NumberOfCores; $threads += [int]$c.NumberOfLogicalProcessors }
  $av = $null; $avUp = $null
  try {
    if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
      $mp = Get-MpComputerStatus -ErrorAction Stop
      if ($mp.AntivirusEnabled) { $av = 'Windows Defender: đang bật' } else { $av = 'Windows Defender: đang TẮT' }
      if ($mp.AntivirusSignatureLastUpdated) { $avUp = $mp.AntivirusSignatureLastUpdated.ToString('yyyy-MM-ddTHH:mm:ss') }
    }
  } catch { }
  $patch = $null
  try { $hf = Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn -Descending | Select-Object -First 1; if ($hf -and $hf.InstalledOn) { $patch = $hf.InstalledOn.ToString('yyyy-MM-dd') } } catch { }
  $apps = @()
  try {
    $seen = @{}
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')) {
      foreach ($a in @(Get-ItemProperty -Path $k -ErrorAction SilentlyContinue)) {
        if (-not $a.DisplayName -or $a.SystemComponent -eq 1) { continue }
        $key = ([string]$a.DisplayName) + '|' + ([string]$a.DisplayVersion)
        if ($seen.ContainsKey($key)) { continue }
        $seen[$key] = 1
        $apps += @{ n = ([string]$a.DisplayName); v = ([string]$a.DisplayVersion); p = ([string]$a.Publisher) }
      }
    }
    $apps = @($apps | Sort-Object { $_.n } | Select-Object -First 400)
  } catch { }
  $reboot = $false
  try { if ((Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')) { $reboot = $true } } catch { }
  return @{
    cpu = ([string]$cpu[0].Name).Trim(); cores = $cores; threads = $threads
    ramGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1); ramType = $ramType; ramSticks = $ramSticks; ramSlots = $ramSlots
    gpu = ($gpu | ForEach-Object { [string]$_.Name }) -join '; '
    board = (([string]$bd.Manufacturer) + ' ' + ([string]$bd.Product)).Trim()
    bios = ([string]$bios.SMBIOSBIOSVersion); serial = ([string]$bios.SerialNumber)
    model = (([string]$cs.Manufacturer) + ' ' + ([string]$cs.Model)).Trim()
    os = [string]$os.Caption; osBuild = [string]$os.Version; arch = [string]$os.OSArchitecture
    domain = [string]$cs.Domain
    smartFail = $fail; disks = $disks; macs = $macs; ips = $ips
    av = $av; avUpdated = $avUp; lastPatch = $patch; apps = $apps; rebootPending = $reboot
  }
}


Add-Type -AssemblyName System.Web.Extensions
$Ser = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$Ser.MaxJsonLength = 10485760
try { [Net.ServicePointManager]::SecurityProtocol = 3072 -bor 768 -bor 192 } catch { }

# Ngôn ngữ của agent: vi (mặc định), en, zh. Chọn lúc cài bằng -Lang, lưu trong config.json.
$script:L = 'vi'
function Set-MamLang($l) { $l = ([string]$l).ToLower(); if ($l.StartsWith('zh')) { $script:L = 'zh' } elseif ($l.StartsWith('en')) { $script:L = 'en' } else { $script:L = 'vi' } }
$Tx = @{
  'Thiếu -Server. Ví dụ: -Install -Server http://192.168.1.10:7070' = @('Missing -Server. Example: -Install -Server http://192.168.1.10:7070', '缺少 -Server。示例：-Install -Server http://192.168.1.10:7070')
  'Không đọc được config.json' = @('Cannot read config.json', '无法读取 config.json')
  ' khởi động, server ' = @(' started, server ', ' 已启动，服务器 ')
  'Không lấy được phần cứng: ' = @('Cannot read hardware information: ', '无法获取硬件信息：')
  'Chưa đăng ký được (' = @('Cannot register yet (', '尚未注册成功（')
  'Đã đăng ký với server, mã máy ' = @('Registered with the server, machine id ', '已向服务器注册，设备编号 ')
  'Token không còn hợp lệ, đăng ký lại' = @('Token no longer valid, registering again', '令牌已失效，重新注册')
  'Máy đã bị thu hồi khỏi hệ thống' = @('This machine has been revoked from the system', '此设备已被系统吊销')
  'Không liên lạc được server (' = @('Cannot reach the server (', '无法连接服务器（')
  'Lỗi vòng lặp: ' = @('Loop error: ', '循环出错：')
  'Đã cài MAM Agent vào ' = @('MAM Agent installed in ', 'MAM 代理已安装到 ')
  ' và đăng ký chạy cùng Windows. Máy sẽ hiện trên Console sau vài giây.' = @(' and registered to start with Windows. The machine will appear in the Console within seconds.', ' 并已注册为随 Windows 启动。几秒钟后设备会出现在控制台中。')
  'Không tìm thấy agent đã cài.' = @('No installed agent found.', '未找到已安装的代理。')
  'Tài khoản Super admin' = @('Super admin username', '超级管理员账号')
  'Mật khẩu' = @('Password', '密码')
  'Bị từ chối: ' = @('Refused: ', '被拒绝：')
  'Đã gỡ MAM Agent.' = @('MAM Agent uninstalled.', 'MAM 代理已卸载。')
  'Dùng: -Install -Server http://IP:7070 [-Lang en]  |  -Uninstall  |  -Run' = @('Usage: -Install -Server http://IP:7070 [-Lang en]  |  -Uninstall  |  -Run', '用法：-Install -Server http://IP:7070 [-Lang zh]  |  -Uninstall  |  -Run')
  'MAM: quản trị viên yêu cầu khởi động lại máy' = @('MAM: an administrator requested a restart', 'MAM：管理员请求重启计算机')
  'MAM: quản trị viên yêu cầu tắt máy' = @('MAM: an administrator requested a shutdown', 'MAM：管理员请求关闭计算机')
}
function T($k) { if ($script:L -eq 'vi' -or -not $Tx.ContainsKey($k)) { return $k }; if ($script:L -eq 'zh') { return $Tx[$k][1] } else { return $Tx[$k][0] } }

function Write-Log($m) {
  try {
    if ((Test-Path $LogPath) -and ((Get-Item $LogPath).Length -gt 2MB)) { Remove-Item $LogPath -Force }
    Add-Content -Path $LogPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m)
  } catch { }
}

function Load-Config { if (Test-Path $CfgPath) { return $Ser.DeserializeObject((Get-Content $CfgPath -Raw)) } return $null }
function Save-Config($c) { Set-Content -Path $CfgPath -Value (ConvertTo-MamJson $c) -Encoding UTF8 }

# Gửi POST JSON, trả về @{ code; body }
function Invoke-Mam($path, $obj, $token) {
  $wc = New-Object System.Net.WebClient
  $wc.Encoding = [Text.Encoding]::UTF8
  $wc.Headers['Content-Type'] = 'application/json'
  if ($token) { $wc.Headers['Authorization'] = 'Bearer ' + $token }
  try {
    $body = $wc.UploadString(($script:Cfg['server']).TrimEnd('/') + $path, 'POST', (ConvertTo-MamJson $obj))
    return @{ code = 200; body = $body }
  } catch [System.Net.WebException] {
    $r = $_.Exception.Response
    if ($r -ne $null) {
      $sr = New-Object IO.StreamReader($r.GetResponseStream()); $txt = $sr.ReadToEnd(); $sr.Close()
      return @{ code = [int]$r.StatusCode; body = $txt }
    }
    return @{ code = 0; body = $_.Exception.Message }
  }
}

function Get-Net {
  foreach ($n in @(Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -and $_.DefaultIPGateway })) {
    foreach ($ip in @($n.IPAddress)) { if ($ip -and $ip -notmatch ':') { return @{ ip = [string]$ip; mac = ([string]$n.MACAddress).ToUpper() } } }
  }
  return @{ ip = ''; mac = '' }
}

function Get-MamMetrics {
  $cpus = @(Get-WmiObject Win32_Processor); $sum = 0; foreach ($c in $cpus) { $sum += [double]$c.LoadPercentage }
  $cpu = 0; if ($cpus.Count -gt 0) { $cpu = $sum / $cpus.Count }
  $os = Get-WmiObject Win32_OperatingSystem
  $ram = 0; if ($os.TotalVisibleMemorySize -gt 0) { $ram = 100 * (1 - ($os.FreePhysicalMemory / $os.TotalVisibleMemorySize)) }
  $up = [int]((Get-Date) - $os.ConvertToDateTime($os.LastBootUpTime)).TotalSeconds
  $disks = @()
  foreach ($d in @(Get-WmiObject Win32_LogicalDisk -Filter 'DriveType=3')) {
    if ($d.Size) { $disks += @{ name = [string]$d.DeviceID; totalGB = [math]::Round($d.Size / 1GB, 1); freeGB = [math]::Round($d.FreeSpace / 1GB, 1) } }
  }
  $user = [string](Get-WmiObject Win32_ComputerSystem).UserName
  return @{ cpu = [math]::Round($cpu, 1); ram = [math]::Round($ram, 1); uptime = $up; disks = $disks; user = $user }
}

function Invoke-MamCommand($type, $args2) {
  try {
    switch ($type) {
      'restart'  { & shutdown.exe /r /t 10 /c (T 'MAM: quản trị viên yêu cầu khởi động lại máy'); return @($true, 'Đã thực hiện') }
      'shutdown' { & shutdown.exe /s /t 10 /c (T 'MAM: quản trị viên yêu cầu tắt máy'); return @($true, 'Đã thực hiện') }
      'lock'     { & tsdiscon.exe console 2>&1 | Out-Null; return @($true, 'Đã thực hiện') }   # cần Windows Pro trở lên
      'message'  { & msg.exe * /TIME:120 ([string]$args2['text']) 2>&1 | Out-Null; return @($true, 'Đã thực hiện') }
      default    { return @($false, 'Lệnh không hỗ trợ: ' + $type) }
    }
  } catch { return @($false, 'Lỗi: ' + $_.Exception.Message) }
}

function Start-MamLoop {
  $script:Cfg = Load-Config
  if ($script:Cfg -eq $null) { Write-Log (T 'Không đọc được config.json'); return }
  if ($script:Cfg.ContainsKey('lang')) { Set-MamLang $script:Cfg['lang'] }
  Write-Log ('MAM Agent PowerShell ' + $Version + (T ' khởi động, server ') + $script:Cfg['server'])
  Start-Sleep -Seconds (Get-Random -Minimum 0 -Maximum 4)
  $hw = $null; $hwAt = [DateTime]::MinValue; $temp = $null; $tempAt = [DateTime]::MinValue; $interval = 5
  while ($true) {
    try {
      if ($hw -eq $null -or ((Get-Date) - $hwAt).TotalMinutes -gt 60) { try { $hw = Get-MamHw } catch { Write-Log ((T 'Không lấy được phần cứng: ') + $_.Exception.Message) }; $hwAt = Get-Date }
      if (-not $script:Cfg['token']) {
        $nm = $script:Cfg['name']; if (-not $nm) { $nm = $env:COMPUTERNAME }
        $net = Get-Net
        $os = [string](Get-WmiObject Win32_OperatingSystem).Caption
        $r = Invoke-Mam '/api/agent/enroll' @{ name = $nm; os = $os; mac = $net.mac; ip = $net.ip; key = [string]$script:Cfg['key']; hw = $hw } $null
        if ($r.code -ne 200) { Write-Log ((T 'Chưa đăng ký được (') + $r.code + '): ' + $r.body); Start-Sleep -Seconds 15; continue }
        $o = $Ser.DeserializeObject($r.body); $script:Cfg['id'] = $o['id']; $script:Cfg['token'] = $o['token']; Save-Config $script:Cfg
        Write-Log ((T 'Đã đăng ký với server, mã máy ') + $o['id'])
      }
      if (((Get-Date) - $tempAt).TotalSeconds -gt 60) { $temp = Get-MamTemp; $tempAt = Get-Date }
      $m = Get-MamMetrics; $net = Get-Net
      $rep = @{ cpu = $m.cpu; ram = $m.ram; temp = $temp; uptime = $m.uptime; disks = $m.disks; user = $m.user; ip = $net.ip; ver = $Version }
      if (((Get-Date) - $hwAt).TotalSeconds -lt 10) { $rep['hw'] = $hw }
      $r = Invoke-Mam '/api/agent/report' $rep $script:Cfg['token']
      if ($r.code -eq 401) { Write-Log (T 'Token không còn hợp lệ, đăng ký lại'); $script:Cfg['token'] = ''; continue }
      if ($r.code -eq 403) { Write-Log (T 'Máy đã bị thu hồi khỏi hệ thống'); Start-Sleep -Seconds 300; continue }
      if ($r.code -eq 200) {
        $o = $Ser.DeserializeObject($r.body)
        if ($o['interval'] -ge 2 -and $o['interval'] -le 60) { $interval = [int]$o['interval'] }
        foreach ($c in @($o['commands'])) {
          if ($c -eq $null) { continue }
          $res = Invoke-MamCommand ([string]$c['type']) $c['args']
          [void](Invoke-Mam '/api/agent/result' @{ id = [string]$c['id']; ok = [bool]$res[0]; output = [string]$res[1] } $script:Cfg['token'])
        }
      } else { Write-Log ((T 'Không liên lạc được server (') + $r.code + ')') }
    } catch { Write-Log ((T 'Lỗi vòng lặp: ') + $_.Exception.Message) }
    Start-Sleep -Seconds $interval
  }
}

function Install-Mam {
  if ($Lang) { Set-MamLang $Lang }
  if (-not $Server) { Write-Host (T 'Thiếu -Server. Ví dụ: -Install -Server http://192.168.1.10:7070'); exit 2 }
  if ($Server -notmatch '^https?://') { $script:Server = 'http://' + $Server }
  New-Item -ItemType Directory -Force -Path $Dir | Out-Null
  & schtasks.exe /end /tn 'MAM Agent' 2>&1 | Out-Null
  $dst = Join-Path $Dir 'MAM-Agent.ps1'
  if ($ScriptPath -ne $dst) { Copy-Item -Path $ScriptPath -Destination $dst -Force }
  Set-Content -Path $CfgPath -Value (ConvertTo-MamJson @{ server = $Server; key = $Key; name = $Name; lang = $script:L; id = ''; token = '' }) -Encoding UTF8
  & icacls.exe $Dir /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' 2>&1 | Out-Null
  $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>MAM Agent - giám sát máy trong mạng LAN</Description></RegistrationInfo>
  <Triggers>
    <BootTrigger><Enabled>true</Enabled></BootTrigger>
    <TimeTrigger><Repetition><Interval>PT1M</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition><StartBoundary>2020-01-01T00:00:00</StartBoundary><Enabled>true</Enabled></TimeTrigger>
  </Triggers>
  <Principals><Principal id="Author"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>false</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>true</Hidden>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <RestartOnFailure><Interval>PT1M</Interval><Count>999</Count></RestartOnFailure>
  </Settings>
  <Actions Context="Author"><Exec><Command>powershell.exe</Command><Arguments>-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "$dst" -Run</Arguments></Exec></Actions>
</Task>
"@
  $xp = Join-Path $env:TEMP 'mam-task.xml'
  [IO.File]::WriteAllText($xp, $xml, [Text.Encoding]::Unicode)
  & schtasks.exe /create /tn 'MAM Agent' /xml $xp /f
  Remove-Item $xp -Force -ErrorAction SilentlyContinue
  & schtasks.exe /run /tn 'MAM Agent' | Out-Null
  Write-Host ((T 'Đã cài MAM Agent vào ') + $Dir + (T ' và đăng ký chạy cùng Windows. Máy sẽ hiện trên Console sau vài giây.'))
}

function Uninstall-Mam {
  $script:Cfg = Load-Config
  if ($script:Cfg -eq $null) { Write-Host (T 'Không tìm thấy agent đã cài.'); exit 1 }
  if ($script:Cfg.ContainsKey('lang')) { Set-MamLang $script:Cfg['lang'] }
  $u = Read-Host (T 'Tài khoản Super admin')
  $sec = Read-Host (T 'Mật khẩu') -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec); $pw = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
  $r = Invoke-Mam '/api/agent/uninstall' @{ user = $u; password = $pw } $script:Cfg['token']
  if ($r.code -ne 200) { Write-Host ((T 'Bị từ chối: ') + $r.body); exit 1 }
  & schtasks.exe /end /tn 'MAM Agent' 2>&1 | Out-Null
  & schtasks.exe /delete /tn 'MAM Agent' /f 2>&1 | Out-Null
  Start-Process cmd.exe -ArgumentList ('/c ping 127.0.0.1 -n 4 >nul & rmdir /s /q "' + $Dir + '"') -WindowStyle Hidden
  Write-Host (T 'Đã gỡ MAM Agent.')
}

if ($Install) { Install-Mam } elseif ($Uninstall) { Uninstall-Mam } elseif ($Run) { Start-MamLoop } else { Write-Host (T 'Dùng: -Install -Server http://IP:7070 [-Lang en]  |  -Uninstall  |  -Run') }
