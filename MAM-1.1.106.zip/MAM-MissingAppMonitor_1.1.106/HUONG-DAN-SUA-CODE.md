# MAM 1.1.106 · Hướng dẫn sửa và build lại mã nguồn

Mã nguồn đầy đủ nằm trong thư mục `source/`. Các file cài và file chạy sẵn nằm ngoài (`MAM-Server-Setup.exe`, `MAM-Agent-Setup.exe`, `server/`, `agent/`, `console/`).

## 1. Cần cài
- **Go 1.24 trở lên**: https://go.dev/dl/ (bản Windows .msi). Mở PowerShell mới, gõ `go version` để kiểm.
- Không cần mạng khi build: thư viện SQLite đã nằm sẵn trong `source/server/vendor/`.
- Chỉ khi muốn dựng lại trọn bộ phát hành bằng `build.sh` mới cần thêm Git Bash, `python3` và `zip`.

## 2. Sửa ở đâu
| Muốn sửa | File |
|---|---|
| Giao diện Console (web) | `source/server/web/app.js`, `style.css`, `index.html` |
| Chữ hiển thị tiếng Anh/Trung | `source/server/web/i18n.js` (khóa là câu tiếng Việt) |
| API, phân quyền, cảnh báo, lưu dữ liệu | `source/server/*.go` (`main.go` là danh sách đường dẫn API) |
| Agent trên máy nhân viên | `source/agent/*.go`; phần đọc phần cứng Windows ở `source/agent/lib.ps1` |
| Cửa sổ MAM trên máy nhân viên | `source/agent/ui.html` |
| Bộ cài có giao diện | `source/installer/setup-server/`, `source/installer/setup-agent/` |

Giao diện Console được nhúng vào `mam-server.exe`: sửa file trong `server/web/` xong phải build lại server mới thấy.

## 3. Build nhanh trên Windows (PowerShell)
Mở PowerShell trong thư mục `source`:

```powershell
# Server
cd server
go test ./...
go build -trimpath -ldflags "-s -w" -o ..\out\mam-server.exe .
cd ..

# Agent (chép hiệu ứng logo dùng chung trước)
Copy-Item server\web\missing-intro.js agent\missing-intro.js
cd agent
go build -trimpath -ldflags "-s -w" -o ..\out\mam-agent.exe .
$env:GOARCH = "386"; go build -trimpath -ldflags "-s -w" -o ..\out\mam-agent-x86.exe .; Remove-Item Env:GOARCH
cd ..

# Console desktop (không bắt buộc)
cd console
go build -trimpath -ldflags "-s -w -H windowsgui -X main.Version=1.1.106" -o ..\out\mam-console.exe .
cd ..
```

Build cho Linux/macOS: đặt `$env:GOOS = "linux"` (hoặc `"darwin"`) và `$env:GOARCH = "amd64"` (hoặc `"arm64"`) trước lệnh `go build`.

## 4. Đổi số phiên bản
Sửa `const Version` trong `source/server/main.go` và `source/agent/main.go`, ví dụ `1.1.106` → `1.1.107`.
Agent tự cập nhật bằng cách so số này: không tăng số thì các máy nhân viên không nhận bản agent mới.

## 5. Thay bản đang chạy
**Trước hết sao lưu thư mục dữ liệu** (mặc định `C:\ProgramData\MAM`, trong đó có `mam.db`).

Server (PowerShell quyền Administrator):
```powershell
schtasks /end /tn "MAM Server"
Copy-Item .\out\mam-server.exe "C:\Program Files\MAM Server\mam-server.exe" -Force
schtasks /run /tn "MAM Server"
```

Agent: chép `mam-agent.exe` và `mam-agent-x86.exe` mới vào `C:\Program Files\MAM Server\` (cạnh `mam-server.exe`). Máy nhân viên đang chạy agent cũ sẽ tự tải bản mới trong vài phút, nếu số phiên bản mới lớn hơn và tự cập nhật đang bật trong Cài đặt.

## 6. Dựng lại trọn bộ phát hành (tùy chọn)
Trên Linux, macOS hoặc Git Bash có `python3` và `zip`: chạy `./build.sh` trong `source/`, kết quả ở `source/dist/MAM-<phiên bản>.zip`, gồm mọi nền tảng và hai bộ cài `.exe`.

## 7. Lưu ý
- Bản cập nhật agent không được ký số: ai giả được server là đẩy được agent lạ xuống máy nhân viên. Chỉ để server trong mạng nội bộ tin cậy.
- Mặc định chạy HTTP không mã hóa. Muốn HTTPS: chạy server với `-cert file.crt -key file.key`.
- Đừng sửa thư mục `vendor/`.
