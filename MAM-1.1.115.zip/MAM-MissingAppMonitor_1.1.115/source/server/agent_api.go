package main

import (
	"log"
	"net/http"
	"strings"
	"time"
)

type reportIn struct {
	CPU     float64                `json:"cpu"`
	RAM     float64                `json:"ram"`
	Temp    *float64               `json:"temp"`
	Uptime  int64                  `json:"uptime"`
	Disks   []Disk                 `json:"disks"`
	User    string                 `json:"user"`
	IP      string                 `json:"ip"`
	Ver     string                 `json:"ver"`
	Arch    string                 `json:"arch"`
	Hw      map[string]interface{} `json:"hw"`
	Threats []ThreatIn             `json:"threats"`
	Macs    []string               `json:"macs"`
	Events  []SysEvent             `json:"events"`
	Host    string                 `json:"host"`
	OS      string                 `json:"os"`
	UpdNote string                 `json:"updNote"` // kết quả lượt tự cập nhật gần nhất của agent
}

func (s *Server) agentMachine(r *http.Request) *Machine {
	h := r.Header.Get("Authorization")
	if !strings.HasPrefix(h, "Bearer ") {
		return nil
	}
	m := s.tok[sha(strings.TrimPrefix(h, "Bearer "))]
	if m == nil || m.Revoked {
		return nil
	}
	return m
}

// agentRevoked: token có trong sổ nhưng đã bị thu hồi (khác với token lạ).
func (s *Server) agentRevoked(r *http.Request) bool {
	h := r.Header.Get("Authorization")
	m := s.tok[sha(strings.TrimPrefix(h, "Bearer "))]
	return m != nil && m.Revoked
}

// Máy client tự đăng ký: không cần tài khoản, không ai phải duyệt.
func (s *Server) hEnroll(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		jerr(w, 405, "Sai phương thức")
		return
	}
	var in struct {
		Name, OS, MAC, IP, Key string
		Hw                     map[string]interface{}
	}
	if readJSON(r, &in) != nil || strings.TrimSpace(in.Name) == "" || len(in.Name) > 60 {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if k := s.st.Settings.EnrollKey; k != "" && in.Key != k {
		jerr(w, 403, "Sai mã đăng ký")
		return
	}
	tok := rid(32)
	var m *Machine
	if in.MAC != "" {
		// cài lại agent trên cùng máy (cùng MAC): dùng lại bản ghi cũ, kể cả đã thu hồi, để không thành hai máy
		// trong danh sách và cảnh báo, lịch sử vẫn liền một máy. Ưu tiên bản ghi đang dùng.
		for _, x := range s.st.Machines {
			if x.MAC == in.MAC && (m == nil || m.Revoked && !x.Revoked) {
				m = x
			}
		}
	}
	if m != nil { // cấp token mới, giữ nhóm và tên
		delete(s.tok, m.TokenHash)
		m.Revoked = false
	} else {
		m = &Machine{ID: rid(5), Registered: time.Now(), Name: strings.TrimSpace(in.Name)}
		s.st.Machines = append(s.st.Machines, m)
	}
	m.TokenHash = sha(tok)
	m.OS, m.IP, m.MAC, m.Hw, m.LastSeen = in.OS, in.IP, in.MAC, in.Hw, time.Now()
	s.tok[m.TokenHash] = m
	s.save()
	s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Máy", Msg: "Máy " + m.Name + " cài agent và tự đăng ký", Target: m.Name})
	jok(w, map[string]interface{}{"id": m.ID, "token": tok, "interval": 5})
}

func (s *Server) hReport(w http.ResponseWriter, r *http.Request) {
	var in reportIn
	if r.Method != "POST" || readJSON(r, &in) != nil {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	s.mu.Lock()
	m := s.agentMachine(r)
	if m == nil {
		rev := s.agentRevoked(r)
		s.mu.Unlock()
		if rev {
			jerr(w, 403, "revoked")
		} else {
			jerr(w, 401, "unknown")
		}
		return
	}
	now := time.Now()
	l := s.live[m.ID]
	if l == nil {
		l = &Live{}
		s.live[m.ID] = l
	}
	l.CPU, l.RAM, l.Temp, l.Uptime, l.Disks, l.User, l.Ver, l.At = clamp(in.CPU), clamp(in.RAM), in.Temp, in.Uptime, in.Disks, in.User, in.Ver, now
	if len(in.Macs) > 0 && len(in.Macs) <= 8 {
		m.MACs = in.Macs
	}
	if in.IP != "" {
		m.IP = in.IP
	}
	if in.Hw != nil {
		rateDisks(in.Hw)
		m.Hw = in.Hw
	}
	m.LastSeen = now
	persist := false
	// vì sao máy này chưa lên bản mới; lên đúng bản rồi thì xóa ghi chú đi
	if n := cut(in.UpdNote, 300); n != "" {
		m.UpdNote, m.UpdAt, persist = n, now, true
	} else if m.UpdNote != "" && !s.agentOutdated(in.Ver) {
		m.UpdNote, m.UpdAt, persist = "", time.Time{}, true
	}
	// tên Windows chỉ gửi lúc đăng ký; agent mới gửi kèm mỗi báo cáo nên máy cũ cũng được sửa lại
	if o := cut(in.OS, 120); o != "" && o != m.OS {
		m.OS = o
		persist = true
	}
	if h := cut(in.Host, 63); h != "" && h != m.Host {
		// đổi tên máy trong Windows (System > About > Rename) thì tên trên MAM đổi theo; lần đầu chỉ ghi nhận
		if m.Host != "" && m.Name != h {
			old := m.Name
			s.setMachineName(m, h)
			persist = true
			s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Máy", Msg: "Máy đổi tên trong Windows: " + old + " thành " + h, Target: h})
		}
		m.Host = h
	}
	s.upMark(m.ID, now.Unix(), in.Uptime)  // không lưu ngay: 1000 máy bật cùng lúc sẽ nghẽn; watchdog lưu mỗi phút
	defer evAppend(s.dir, m.ID, in.Events) // chạy sau khi đã nhả s.mu
	s.threatsIn(m, in.Threats)
	s.patchCheck(m)
	if now.Sub(l.lastHist) >= 30*time.Second {
		smp := Sample{T: now.Unix(), CPU: float32(l.CPU), RAM: float32(l.RAM), Temp: -1}
		if l.Temp != nil {
			smp.Temp = float32(*l.Temp)
		}
		l.Hist = append(l.Hist, smp)
		if len(l.Hist) > 480 {
			l.Hist = l.Hist[len(l.Hist)-480:]
		}
		l.lastHist = now
	}
	s.checkMachine(m, l)
	out := []map[string]interface{}{}
	for _, c := range s.st.Commands {
		if c.Machine == m.ID && c.Status == "pending" {
			c.Status = "sent"
			persist = true
			out = append(out, map[string]interface{}{"id": c.ID, "type": c.Type, "args": c.Args})
		}
	}
	if persist {
		s.save()
	}
	interval := 5
	pol := s.policyFor(m)
	scr := s.screenPendingFor(m.ID)
	dts := s.deviceTypes()
	cl := s.contactLabel()
	s.mu.Unlock()
	jok(w, map[string]interface{}{"commands": out, "name": m.Name, "interval": interval, "policy": pol, "update": s.updateFor(in.Ver, in.Arch), "screen": scr, "deviceTypes": dts, "contactLabel": cl})
}

func clamp(v float64) float64 {
	if v < 0 {
		return 0
	}
	if v > 100 {
		return 100
	}
	return v
}

// Gỡ agent bằng mật khẩu gỡ do Super admin đặt trong Console: agent hỏi server trước khi tự xóa.
// Không dùng tài khoản quản trị để khỏi lộ tài khoản ra máy người dùng.
func (s *Server) hUninstall(w http.ResponseWriter, r *http.Request) {
	var in struct{ Code string }
	if r.Method != "POST" || readJSON(r, &in) != nil {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.agentMachine(r)
	if m == nil {
		jerr(w, 401, "Token không hợp lệ")
		return
	}
	if !s.uninstCodeOK(w, r, m, in.Code) {
		return
	}
	m.Revoked = true
	delete(s.live, m.ID)
	s.save()
	s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Máy", Msg: "Gỡ agent khỏi máy " + m.Name + " bằng mật khẩu gỡ", Target: m.Name, Sens: true})
	jok(w, map[string]bool{"ok": true})
}

// uninstCodeOK kiểm mật khẩu gỡ agent (dùng cho gỡ agent và đổi tên máy trên agent); sai thì tự trả lỗi.
// Sai 5 lần khóa 1 phút theo IP, chung bộ đếm cho cả hai việc. Gọi khi đang giữ s.mu.
func (s *Server) uninstCodeOK(w http.ResponseWriter, r *http.Request, m *Machine, code string) bool {
	key := "unins|" + clientIP(r)
	if f := s.fails[key]; f != nil && time.Now().Before(f.until) {
		jerr(w, 429, "Sai quá nhiều lần, thử lại sau 1 phút")
		return false
	}
	if s.st.UninstHash == "" {
		jerr(w, 409, "Quản trị viên chưa đặt mật khẩu gỡ")
		return false
	}
	if hashPw(code, s.st.UninstSalt, pbkdfIter) != s.st.UninstHash {
		f := s.fails[key]
		if f == nil {
			f = &failRec{}
			s.fails[key] = f
		}
		f.n++
		left := 5 - f.n
		if f.n >= 5 {
			f.until, f.n = time.Now().Add(time.Minute), 0
		}
		s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Máy", Msg: "Nhập sai mật khẩu gỡ trên " + m.Name, Target: m.Name, Sens: true})
		if left <= 0 {
			jerr(w, 403, "Mật khẩu gỡ không đúng. Đã khóa 1 phút")
		} else {
			jerr(w, 403, "Mật khẩu gỡ không đúng. Còn "+itoa(left)+" lần thử")
		}
		return false
	}
	delete(s.fails, key)
	return true
}

// Người ngồi máy trả lời tin nhắn của admin: ghi vào nhật ký để admin xem ở Console.
func (s *Server) hReply(w http.ResponseWriter, r *http.Request) {
	var in struct{ Text, TraID string }
	if r.Method != "POST" || readJSON(r, &in) != nil {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	t := strings.TrimSpace(in.Text)
	if t == "" || len([]rune(t)) > 300 {
		jerr(w, 400, "Nội dung 1 đến 300 ký tự")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.agentMachine(r)
	if m == nil {
		jerr(w, 401, "Token không hợp lệ")
		return
	}
	l := s.addChat(m.ID, m.Name, t, true)
	if in.TraID != "" { // trả lời một tin cũ: chép sẵn tên và nội dung tin gốc
		for _, c := range s.st.Chat {
			if c.Machine == m.ID && c.ID == in.TraID && !c.Thu {
				l.TraID, l.TraBy, l.TraText = c.ID, c.By, clip(c.Text, 120)
			}
		}
	}
	s.save()
	s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Tin nhắn", Msg: "Máy " + m.Name + " trả lời: " + t, Target: m.Name})
	for _, sc := range s.screens {
		if sc.Machine == m.ID && sc.Status == "active" {
			sc.Chat = append(sc.Chat, ChatMsg{By: m.Name, Text: t, At: time.Now(), Mine: false})
			if len(sc.Chat) > 200 {
				sc.Chat = sc.Chat[len(sc.Chat)-200:]
			}
			break
		}
	}
	jok(w, map[string]string{"id": l.ID}) // máy giữ ID này để sau còn thu hồi hay sửa chính tin đó
}

// hAgentChatAct: người ngồi máy thả cảm xúc / thu hồi / sửa tin nhắn. Chỉ đụng được tin của CHÍNH
// họ — tin của admin là lời admin, không ai sửa miệng người khác.
func (s *Server) hAgentChatAct(w http.ResponseWriter, r *http.Request) {
	var in struct{ ID, Lam, Cam, Text string }
	if r.Method != "POST" || readJSON(r, &in) != nil {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	text := strings.TrimSpace(in.Text)
	if in.Lam == "sua" && (len([]rune(text)) < 1 || len([]rune(text)) > 300) {
		jerr(w, 400, "Nội dung 1 đến 300 ký tự")
		return
	}
	if in.Lam == "cam" && in.Cam != "" && !camCho[in.Cam] {
		jerr(w, 400, "Cảm xúc không hợp lệ")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.agentMachine(r)
	if m == nil {
		jerr(w, 401, "Token không hợp lệ")
		return
	}
	var l *ChatLine
	for _, c := range s.st.Chat {
		if c.Machine == m.ID && c.ID == in.ID {
			l = c
		}
	}
	if l == nil {
		jerr(w, 404, "Không có tin nhắn này")
		return
	}
	switch in.Lam {
	case "cam":
		l.CamMay = in.Cam
	case "thu", "sua":
		if !l.Client {
			jerr(w, 403, "Đây là tin của quản trị viên")
			return
		}
		if l.Thu {
			jerr(w, 400, "Tin này đã thu hồi rồi")
			return
		}
		if in.Lam == "thu" {
			l.Thu, l.Text, l.Sua = true, "", false
			if l.Tep != "" { // thu hồi là xóa thật, kể cả file đã gửi
				xoaTepChat(l.ID)
				l.Tep, l.TepCo, l.TepAnh = "", 0, false
			}
		} else {
			l.Text, l.Sua = text, true
		}
	default:
		jerr(w, 400, "Không hiểu muốn làm gì với tin này")
		return
	}
	chatBump()
	s.save()
	jok(w, map[string]bool{"ok": true})
}

// hAgentRename: đổi tên máy ngay trên client, phải nhập mật khẩu gỡ agent (admin đổi trong Console thì không cần).
func (s *Server) hAgentRename(w http.ResponseWriter, r *http.Request) {
	var in struct{ Name, Code string }
	if r.Method != "POST" || readJSON(r, &in) != nil {
		jerr(w, 400, "Dữ liệu không hợp lệ")
		return
	}
	in.Name = strings.TrimSpace(in.Name)
	if n := len([]rune(in.Name)); n < 1 || n > 40 {
		jerr(w, 400, "Tên máy 1 đến 40 ký tự")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	m := s.agentMachine(r)
	if m == nil {
		jerr(w, 401, "Token không hợp lệ")
		return
	}
	if old := m.Name; old != in.Name {
		if !s.uninstCodeOK(w, r, m, in.Code) {
			return
		}
		s.setMachineName(m, in.Name)
		s.save()
		s.audit(AuditEntry{User: "system", Name: "Hệ thống", Role: "sys", IP: clientIP(r), Kind: "Máy", Msg: "Người dùng đổi tên máy " + old + " thành " + in.Name, Target: in.Name})
	}
	jok(w, map[string]bool{"ok": true})
}

// hAgentChatTep: người ngồi máy gửi file lên (POST, thân là nội dung file, ?ten= tên, ?text= lời
// nhắn), hoặc cửa sổ MAM tải file của một dòng chat về (GET ?tin=<id dòng>) — cửa sổ không có
// phiên đăng nhập Console nên phải đi vòng qua agent bằng token máy.
func (s *Server) hAgentChatTep(w http.ResponseWriter, r *http.Request) {
	s.mu.RLock()
	m := s.agentMachine(r)
	var mid, name string
	if m != nil {
		mid, name = m.ID, m.Name
	}
	s.mu.RUnlock()
	if m == nil {
		jerr(w, 401, "Token không hợp lệ")
		return
	}

	if r.Method == "GET" {
		tin := r.URL.Query().Get("tin")
		s.mu.RLock()
		var l *ChatLine
		for _, c := range s.st.Chat {
			if c.Machine == mid && c.ID == tin && c.Tep != "" && !c.Thu {
				cp := *c
				l = &cp
			}
		}
		s.mu.RUnlock()
		if l == nil {
			http.NotFound(w, r)
			return
		}
		traTep(w, r, l)
		return
	}
	if r.Method != "POST" {
		jerr(w, 405, "Phương thức không hợp lệ")
		return
	}

	ten := tenTepSach(r.URL.Query().Get("ten"))
	text := strings.TrimSpace(r.URL.Query().Get("text"))
	if len([]rune(text)) > 300 {
		jerr(w, 400, "Nội dung 1 đến 300 ký tự")
		return
	}
	tmp, co, anh, err := nhanTep(w, r)
	if err != nil {
		jerr(w, 400, TErr(err.Error()))
		return
	}
	s.mu.Lock()
	l, err := s.themTep(mid, name, text, "", tmp, ten, co, anh, true)
	if err != nil {
		s.mu.Unlock()
		jerr(w, 500, "Không lưu được file: "+err.Error())
		return
	}
	if nDon, thu := s.gonTepCu(); nDon > 0 {
		log.Printf(T("Thư mục file chat đầy, đã dọn %d file cũ nhất, thu lại %s"), nDon, coTep(thu))
	}
	s.save()
	s.mu.Unlock()
	s.audit(AuditEntry{User: "system", Name: T("Hệ thống"), Role: "sys", IP: clientIP(r), Kind: T("Tin nhắn"),
		Msg: T("Máy %s gửi file %s (%s)", name, ten, coTep(co)), Target: name})
	jok(w, map[string]interface{}{"id": l.ID, "ten": ten, "co": co, "anh": anh})
}
