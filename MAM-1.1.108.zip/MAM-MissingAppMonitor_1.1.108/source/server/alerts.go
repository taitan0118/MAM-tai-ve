package main

import (
	"fmt"
	"strings"
	"time"
)

// checkMachine chạy mỗi lần máy báo cáo. Gọi khi đang giữ s.mu.
func (s *Server) checkMachine(m *Machine, l *Live) {
	cfg := s.st.Settings
	if l.CPU >= cfg.CPU {
		l.CPUHigh++
	} else {
		l.CPUHigh = 0
	}
	s.cond(m, "cpu", "warn", l.CPUHigh >= 6, fmt.Sprintf("CPU %.0f%% liên tục (ngưỡng %.0f%%)", l.CPU, cfg.CPU))
	hot := l.Temp != nil && *l.Temp >= cfg.TempC
	tmsg := ""
	if l.Temp != nil {
		tmsg = fmt.Sprintf("Nhiệt độ bo mạch %.0f°C (ngưỡng %.0f°C)", *l.Temp, cfg.TempC)
	}
	s.cond(m, "temp", "crit", hot, tmsg)
	low, dmsg := false, ""
	for _, d := range l.Disks {
		if d.TotalGB > 0 && d.FreeGB/d.TotalGB*100 <= cfg.DiskFreePc {
			low = true
			dmsg = fmt.Sprintf("Ổ %s chỉ còn %.0f%% trống (ngưỡng %.0f%%)", d.Name, d.FreeGB/d.TotalGB*100, cfg.DiskFreePc)
			break
		}
	}
	s.cond(m, "disk", "warn", low, dmsg)
	s.cond(m, "offline", "crit", false, "") // máy đã báo lại: đóng cảnh báo mất kết nối
}

// catBotCanhBao: nhiều cảnh báo quá thì bỏ bớt cái CŨ NHẤT ĐÃ ĐÓNG, không bao giờ bỏ cái đang mở.
// Trước đây cắt thẳng theo thứ tự nên cảnh báo đang mở cũng bị bỏ; lượt kiểm sau dò không thấy nó nữa
// nên mở thêm một cái y hệt — đó chính là lỗi "cảnh báo cứ lặp lại".
// Số cảnh báo đang mở có trần tự nhiên (mỗi máy/thiết bị mỗi loại chỉ một cái) nên không sợ phình mãi.
func (s *Server) catBotCanhBao() {
	if len(s.st.Alerts) <= 2000 {
		return
	}
	bo := len(s.st.Alerts) - 1500
	giu := make([]*Alert, 0, len(s.st.Alerts))
	for _, a := range s.st.Alerts {
		if bo > 0 && a.Status != "open" {
			bo--
			continue
		}
		giu = append(giu, a)
	}
	s.st.Alerts = giu
}

// moiNhat trả cảnh báo mới nhất của một máy + một loại lỗi (kể cả đã đóng). Gọi khi đang giữ s.mu.
func (s *Server) moiNhat(machine, kind string) *Alert {
	for i := len(s.st.Alerts) - 1; i >= 0; i-- {
		if a := s.st.Alerts[i]; a.Machine == machine && a.Kind == kind {
			return a
		}
	}
	return nil
}

// dangGiu: lỗi này vừa được người ta đóng tay và từ đó tới giờ chưa hết lần nào → đừng báo lại.
// Đây là luật "đã có cảnh báo rồi thì phải có thay đổi thật mới được báo tiếp".
func (s *Server) dangGiu(machine, kind string) bool {
	a := s.moiNhat(machine, kind)
	return a != nil && a.Status != "open" && a.Giu
}

// boGiu: lỗi đã thật sự hết → bỏ dấu giữ, lần hỏng sau là chuyện mới và được báo.
func (s *Server) boGiu(machine, kind string) {
	if a := s.moiNhat(machine, kind); a != nil && a.Giu {
		a.Giu = false
	}
}

// cond mở cảnh báo khi điều kiện đúng, tự đóng khi hết đúng.
func (s *Server) cond(m *Machine, kind, sev string, on bool, msg string) {
	var open *Alert
	// Phải dò HẾT: trước đây chỉ dò ngược 400 dòng nên khi cảnh báo nhiều hơn thế, cái đang mở nằm
	// ngoài tầm dò và mỗi lượt kiểm lại mở thêm một cái y hệt.
	for i := len(s.st.Alerts) - 1; i >= 0; i-- {
		a := s.st.Alerts[i]
		if a.Machine == m.ID && a.Kind == kind && a.Status == "open" {
			open = a
			break
		}
	}
	if !on {
		s.boGiu(m.ID, kind) // lỗi hết rồi: lần hỏng sau là chuyện mới
	}
	switch {
	case on && open == nil:
		if s.dangGiu(m.ID, kind) {
			return // đã đóng tay mà lỗi vẫn y nguyên: không báo lại, cũng không nhắn lại
		}
		s.st.Alerts = append(s.st.Alerts, &Alert{ID: rid(5), Machine: m.ID, Name: m.Name, Kind: kind, Sev: sev, Msg: msg, Opened: time.Now(), Status: "open"})
		s.catBotCanhBao()
		// không lưu ngay: cả nghìn máy tắt cùng lúc sẽ ghi file hàng nghìn lần; watchdog lưu mỗi phút
		s.notify(s.st.Settings, "Cảnh báo: "+m.Name, msg)
	case !on && open != nil:
		open.Status, open.Closed, open.By = "closed", time.Now(), "tự động"
	}
}

// donCanhBaoTrung đóng bớt cảnh báo trùng đã lỡ sinh ra do lỗi dò 400 dòng: mỗi máy + mỗi loại chỉ
// giữ lại một cảnh báo đang mở (cái cũ nhất), còn lại đóng hết. Gọi khi đang giữ s.mu.
// donCanhBaoHinhGia đính chính đám cảnh báo "không ra hình" mà bản ≤ 1.1.102 đẻ ra: hồi đó MAM kết
// luận camera không ra hình ngay cả khi chưa đo được lần nào, hoặc khi lượt đo bị cắt ngang.
//
// Làm đúng kiểu quản lý thiết bị chứ không phải xóa cho sạch mắt:
//   - chỉ đụng loại "devvideo", KHÔNG đụng cảnh báo mất kết nối (sự cố thật, phải có người xác nhận)
//   - ghi rõ ai đóng và vì sao, cảnh báo vẫn còn nguyên ở tab "Đã đóng"
//   - KHÔNG đặt cờ Giu: camera nào không ra hình thật thì lượt đo tới mở lại cảnh báo bình thường
//   - chạy đúng một lần, có cờ trong Cài đặt
// Gọi khi đang giữ s.mu.
func (s *Server) donCanhBaoHinhGia() int {
	if s.st.Settings.DaDonHinhGia {
		return 0
	}
	s.st.Settings.DaDonHinhGia = true
	n := 0
	for _, a := range s.st.Alerts {
		if a.Status != "open" || a.Kind != "devvideo" {
			continue
		}
		a.Status, a.Closed = "closed", time.Now()
		a.By = T("hệ thống · kết luận sai của bản ≤ 1.1.102")
		n++
	}
	return n
}

func (s *Server) donCanhBaoTrung() int {
	giu, n := map[string]bool{}, 0
	for _, a := range s.st.Alerts {
		if a.Status != "open" {
			continue
		}
		k := a.Machine + "\x00" + a.Kind
		if giu[k] {
			a.Status, a.Closed, a.By = "closed", time.Now(), "tự động (trùng)"
			n++
			continue
		}
		giu[k] = true
	}
	return n
}

// watchdog chạy nền: mất kết nối, lệnh treo, lưu lastSeen, sao lưu hằng ngày.
func (s *Server) watchdog() {
	tick := time.NewTicker(15 * time.Second)
	lastSave, lastBackup, lastMirror, lastDisk := time.Now(), time.Time{}, time.Now().Add(-55*time.Minute), time.Time{}
	for range tick.C {
		s.mu.Lock()
		cfg := s.st.Settings
		now := time.Now()
		for _, m := range s.st.Machines {
			if m.Revoked || m.LastSeen.IsZero() {
				continue
			}
			gap := now.Sub(m.LastSeen)
			if gap > time.Duration(cfg.OfflineMin*float64(time.Minute)) {
				s.cond(m, "offline", "crit", true, "Mất kết nối "+khoangVN(int(gap.Minutes())))
			}
			// máy tắt (không báo về) nhiều ngày liền: cảnh báo riêng, tự đóng khi máy bật lại hoặc khi tắt ngưỡng
			long := cfg.OfflineDays > 0 && gap > time.Duration(cfg.OfflineDays*float64(24*time.Hour))
			s.cond(m, "offdays", "warn", long, fmt.Sprintf("Máy không bật %.0f ngày (lần cuối %s)", gap.Hours()/24, m.LastSeen.Format("02/01/2006 15:04")))
		}
		for _, c := range s.st.Commands {
			if c.Status == "sent" && now.Sub(c.Created) > 3*time.Minute {
				c.Status, c.Result, c.Done = "failed", "Agent không phản hồi", now
			}
			if c.Status == "pending" && now.Sub(c.Created) > 3*time.Minute {
				c.Status, c.Result, c.Done = "failed", "Máy không nhận lệnh (offline)", now
			}
		}
		s.sweep(now)
		s.sweepScreens(now)
		for k, v := range s.sess {
			if now.After(v.Exp) {
				delete(s.sess, k)
			}
		}
		if now.Sub(lastSave) > time.Minute {
			s.save()
			lastSave = now
		}
		s.mu.Unlock()
		if now.Sub(lastBackup) > 24*time.Hour {
			s.backup()
			s.mu.RLock()
			dir := s.dir
			s.mu.RUnlock()
			evPrune(dir)
			lastBackup = now
		}
		if now.Sub(lastMirror) > time.Hour {
			lastMirror = now
			go s.runMirror()
		}
		if now.Sub(lastDisk) > 6*time.Hour {
			lastDisk = now
			go s.checkServerDisk()
		}
	}
}

// ThreatIn là một phát hiện virus/nghi ngờ do agent gửi lên (xem agent/threat.go).
type ThreatIn struct {
	ID     string `json:"id"`
	Kind   string `json:"kind"`
	Name   string `json:"name"`
	Detail string `json:"detail"`
	Cause  string `json:"cause"`
	Status string `json:"status"`
}

// threatsIn mở cảnh báo cho mỗi phát hiện mới (theo ID, mỗi ID chỉ báo một lần). Cảnh báo virus
// không tự đóng: người quản trị phải xem và đóng tay. Gọi khi đang giữ s.mu.
func (s *Server) threatsIn(m *Machine, in []ThreatIn) {
	if len(in) > 30 {
		in = in[:30]
	}
	for _, t := range in {
		if t.ID == "" || len(t.ID) > 40 || t.Name == "" {
			continue
		}
		seen := false
		for _, id := range m.ThreatSeen {
			if id == t.ID {
				seen = true
				break
			}
		}
		if seen {
			continue
		}
		m.ThreatSeen = append(m.ThreatSeen, t.ID)
		if len(m.ThreatSeen) > 300 {
			m.ThreatSeen = m.ThreatSeen[len(m.ThreatSeen)-200:]
		}
		kind, sev, msg := "suspect", "warn", "Nghi ngờ mã độc: "+clip(t.Name, 120)
		if t.Kind == "virus" {
			kind, sev = "virus", "crit"
			msg = "Phát hiện virus " + clip(t.Name, 120)
			if t.Detail != "" {
				msg += " tại " + clip(t.Detail, 200)
			}
		} else if t.Detail != "" {
			msg += " - " + clip(t.Detail, 200)
		}
		base := msg // virus + file (không kể trạng thái, nguyên nhân): để nhận ra cùng một phát hiện
		if t.Status != "" {
			msg += " [" + clip(t.Status, 60) + "]"
		}
		if t.Kind == "virus" && t.Cause != "" {
			msg += ". Nguyên nhân có thể: " + clip(t.Cause, 160)
		}
		// Defender phát hiện lại cùng file (quét lại, giải nén lại...) thì ra mã phát hiện mới: không mở thêm cảnh báo
		// nếu máy đã có cảnh báo cùng virus + cùng file đang mở, hoặc mới đóng trong 24 giờ. Cảnh báo đang mở thì cập nhật trạng thái mới.
		if a := s.sameThreatAlert(m.ID, kind, base); a != nil {
			if a.Status != "open" && a.Giu {
				continue // đúng dấu hiệu đó, đại ca đã đóng tay rồi: không báo lại nữa
			}
			if a.Status == "open" && a.Msg != msg {
				a.Msg = msg
				s.save()
			}
			continue
		}
		s.st.Alerts = append(s.st.Alerts, &Alert{ID: rid(5), Machine: m.ID, Name: m.Name, Kind: kind, Sev: sev, Msg: msg, Opened: time.Now(), Status: "open"})
		s.catBotCanhBao()
		s.save()
		s.notify(s.st.Settings, "Cảnh báo: "+m.Name, msg)
	}
}

// sameThreatAlert tìm cảnh báo của máy về cùng một virus/dấu hiệu (base = phần câu trước " [trạng thái]")
// đang mở, hoặc đóng chưa quá 24 giờ. Gọi khi đang giữ s.mu.
func (s *Server) sameThreatAlert(machine, kind, base string) *Alert {
	since := time.Now().Add(-24 * time.Hour)
	// dò hết danh sách: giới hạn 600 dòng cũng là lỗi như trần 400 ngày trước — cảnh báo cũ nằm
	// ngoài tầm dò thì lại đẻ ra một dòng y hệt
	for i := len(s.st.Alerts) - 1; i >= 0; i-- {
		a := s.st.Alerts[i]
		if a.Machine != machine || a.Kind != kind || !(a.Msg == base || strings.HasPrefix(a.Msg, base+" [") || strings.HasPrefix(a.Msg, base+". ")) {
			continue
		}
		// a.Giu: đã đóng tay thì nhớ mãi, không phải chỉ 24 giờ
		if a.Status == "open" || a.Giu || a.Closed.After(since) || a.Opened.After(since) {
			return a
		}
	}
	return nil
}

// patchCheck cảnh báo khi máy Windows hơn 90 ngày chưa cài bản vá nào (lastPatch do agent đọc từ Get-HotFix);
// tự đóng khi đã vá. Gọi khi đang giữ s.mu.
// khoangVN đổi số phút thành câu dễ đọc: 45 phút / 2 tiếng 46 phút / 1 ngày 0 giờ 34 phút.
func khoangVN(phut int) string {
	if phut < 60 {
		return itoa(phut) + " phút"
	}
	if phut < 24*60 {
		return itoa(phut/60) + " tiếng " + itoa(phut%60) + " phút"
	}
	return itoa(phut/(24*60)) + " ngày " + itoa(phut%(24*60)/60) + " giờ " + itoa(phut%60) + " phút"
}

func (s *Server) patchCheck(m *Machine) {
	lp, _ := m.Hw["lastPatch"].(string)
	t, err := time.Parse("2006-01-02", lp)
	if err != nil {
		return
	}
	days := int(time.Since(t).Hours() / 24)
	s.cond(m, "patch", "warn", days > 90, fmt.Sprintf("Máy chưa cài bản vá Windows nào trong %d ngày (lần cuối %s)", days, lp))
}
