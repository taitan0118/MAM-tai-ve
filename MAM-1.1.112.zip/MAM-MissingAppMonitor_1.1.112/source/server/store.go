package main

import (
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"sync"
	"time"
)

// ---------- dữ liệu lưu xuống đĩa ----------

type Account struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	User        string    `json:"user"`
	Role        string    `json:"role"` // super | tech | view
	Scope       []string  `json:"scope"`
	Salt        string    `json:"salt"`
	Hash        string    `json:"hash"`
	Iter        int       `json:"iter"`
	MustChange  bool      `json:"mustChange"`
	Created     time.Time `json:"created"`
	LastLogin   time.Time `json:"lastLogin"`
	TOTP        string    `json:"totp,omitempty"`     // khóa xác thực hai bước (base32); rỗng = chưa bật
	TOTPLast    int64     `json:"totpLast,omitempty"` // bước 30 giây đã dùng gần nhất
	TOTPPending string    `json:"-"`                  // khóa đang chờ xác nhận
}

type Machine struct {
	ID          string                 `json:"id"`
	TokenHash   string                 `json:"tokenHash"`
	Name        string                 `json:"name"`
	OS          string                 `json:"os"`
	Group       string                 `json:"group"`
	IP          string                 `json:"ip"`
	Host        string                 `json:"host,omitempty"` // tên máy trong Windows lần báo cáo gần nhất
	MAC         string                 `json:"mac"`
	MACs        []string               `json:"macs,omitempty"` // MAC thật của mọi card mạng (cho Wake-on-LAN)
	Hw          map[string]interface{} `json:"hw"`
	Registered  time.Time              `json:"registered"`
	LastSeen    time.Time              `json:"lastSeen"`
	Revoked     bool                   `json:"revoked"`
	ThreatSeen  []string               `json:"threatSeen,omitempty"` // ID các phát hiện virus đã báo, để không báo lại
	// Vì sao máy này chưa lên bản agent mới (agent gửi lên sau mỗi lượt tự cập nhật hỏng). Xóa khi máy
	// đã lên đúng bản, để Console chỉ hiện lý do của máy đang thật sự kẹt.
	UpdNote     string                 `json:"updNote,omitempty"`
	UpdAt       time.Time              `json:"updAt,omitempty"`
	RemoteNote  string                 `json:"remoteNote"`           // ID TeamViewer/AnyDesk hoặc địa chỉ RDP, admin tự ghi để tiện mở phần mềm remote desktop ngoài
	LicenseNote string                 `json:"licenseNote"`          // bản quyền Windows/Office/phần mềm máy này, admin tự ghi
}

// DauGhi: một đầu ghi camera. IP là mã nhận dạng luôn — một địa chỉ chỉ có một đầu ghi, khỏi đẻ
// thêm id cho Console phải mang theo.
type DauGhi struct {
	IP   string    `json:"ip"`
	Port int       `json:"port"` // cổng web (ISAPI), thường 80
	User string    `json:"user"`
	Pass string    `json:"pass,omitempty"` // không bao giờ trả về Console
	Ten  string    `json:"ten"`            // tên + model đầu ghi tự khai lúc đăng nhập được
	Kenh int       `json:"kenh"`           // số kênh camera đầu ghi báo; 0 = không đọc được
	Gan  int       `json:"gan"`            // số camera trong MAM gắn được vào đầu ghi này
	At   time.Time `json:"at"`             // lần đăng nhập được gần nhất
}

type Settings struct {
	TempC           float64 `json:"temp"`
	CPU             float64 `json:"cpu"`
	DiskFreePc      float64 `json:"disk"`
	OfflineMin      float64 `json:"offline"`
	OfflineDays     float64 `json:"offlineDays"` // máy không bật quá N ngày thì cảnh báo; 0 = tắt
	EnrollKey       string  `json:"enrollKey"`       // để trống = máy nào cài agent cũng tự đăng ký
	NoAutoUpdate    bool    `json:"noAutoUpdate"`    // true: không tự cập nhật agent
	NoMachineAvatar bool    `json:"noMachineAvatar"` // true: máy không được tự đổi ảnh đại diện
	// Tài khoản dùng chung cho camera: công ty thường đặt cùng một mật khẩu cho cả trăm camera, khai
	// ở đây một lần là mọi camera chưa có tài khoản riêng đều đo được luồng hình.
	CamUser string `json:"camUser"`
	CamPass string `json:"camPass"`
	// Đầu ghi camera (NVR) — NHIỀU cái: một đầu ghi 16 hay 32 kênh không ôm hết 395 camera, công ty
	// có mấy cái thì khai hết mấy cái. Chỉ đổi qua /api/nvr: đăng nhập thử được mới lưu, nên PUT
	// /api/settings phải giữ nguyên (Console gửi cả cục Settings lên, trống là mất).
	Nvrs []DauGhi `json:"nvrs,omitempty"`
	// Đầu ghi khai từ bản 1.1.106–1.1.110 (hồi đó chỉ cho một cái). Lúc khởi động chuyển vào Nvrs
	// rồi xóa, giữ lại mấy ô này chỉ để đọc được dữ liệu cũ.
	NvrIP   string    `json:"nvrIP,omitempty"`
	NvrPort int       `json:"nvrPort,omitempty"`
	NvrUser string    `json:"nvrUser,omitempty"`
	NvrPass string    `json:"nvrPass,omitempty"`
	NvrTen  string    `json:"nvrTen,omitempty"`
	NvrKenh int       `json:"nvrKenh,omitempty"`
	NvrAt   time.Time `json:"nvrAt,omitempty"`
	// Đã đính chính đám cảnh báo "không ra hình" do lỗi kết luận của bản ≤ 1.1.102 chưa. Một lần là
	// thôi: để nó chạy lại mỗi lần khởi động thì cảnh báo thật về sau cũng bị đóng oan.
	DaDonHinhGia bool `json:"daDonHinhGia,omitempty"`
	// Thông báo ra ngoài khi có cảnh báo mới mở
	Telegram string `json:"telegram"` // token bot Telegram
	TgChat   string `json:"tgChat"`   // chat id nhận tin
	Webhook  string `json:"webhook"`  // URL nhận POST JSON {"text":...} — dùng cho Zalo OA (qua trung gian), Slack, n8n...
	SmtpHost string `json:"smtpHost"`
	SmtpPort string `json:"smtpPort"`
	SmtpUser string `json:"smtpUser"`
	SmtpPass string `json:"smtpPass"`
	SmtpTo   string `json:"smtpTo"`
	// Công tắc tắt từng kênh (mặc định false = bật, giữ nguyên hành vi cũ khi có cấu hình)
	TgOff   bool `json:"tgOff"`
	WhOff   bool `json:"whOff"`
	SmtpOff bool `json:"smtpOff"`
	// Thư mục sao lưu thứ hai (ổ khác, USB, NAS); trống = tắt. Đổi qua /api/backups/mirror.
	BackupDir string `json:"backupDir"`
}

type Reply struct {
	By     string    `json:"by"`
	Text   string    `json:"text"`
	At     time.Time `json:"at"`
	Client bool      `json:"client"` // true: người ngồi máy viết
}

// Request: yêu cầu hỗ trợ do người ngồi máy gửi từ cửa sổ MAM.
type Request struct {
	ID         string    `json:"id"`
	Machine    string    `json:"machine"`
	Name       string    `json:"name"`     // tên máy lúc gửi
	User       string    `json:"user"`     // người dùng Windows
	Reporter   string    `json:"reporter"` // tên người báo (tự nhập)
	Phone      string    `json:"phone"`    // SĐT/Zalo người báo
	EmpID      string    `json:"empId"`    // mã nhân viên
	BadPC      string    `json:"badPc"`    // mã máy hư (tự nhập, có thể báo giùm máy khác)
	Text       string    `json:"text"`
	Urgent     bool      `json:"urgent"`
	DeviceType string    `json:"deviceType"` // loại thiết bị hỏng (máy tính, máy in...)
	Status     string    `json:"status"`     // new | working | done
	Solution   string    `json:"solution"`   // cách xử lý, bắt buộc khi chuyển sang done
	SolvedBy   string    `json:"solvedBy"`
	Created    time.Time `json:"created"`
	Updated    time.Time `json:"updated"`
	Replies    []Reply   `json:"replies"`
}

// Policy: chính sách áp cho một nhóm máy (Group "" = máy chưa phân nhóm).
type Policy struct {
	Group   string   `json:"group"`
	USB     bool     `json:"usb"`
	SitesOn bool     `json:"sitesOn"`
	Sites   []string `json:"sites"`
	AppsOn  bool     `json:"appsOn"`
	Apps    []string `json:"apps"`
	HoursOn bool     `json:"hoursOn"`
	From    string   `json:"from"` // HH:MM
	To      string   `json:"to"`
}

type Alert struct {
	ID      string    `json:"id"`
	Machine string    `json:"machine"` // id máy
	Name    string    `json:"name"`
	Kind    string    `json:"kind"` // temp | cpu | disk | offline
	Sev     string    `json:"sev"`  // crit | warn
	Msg     string    `json:"msg"`
	Opened  time.Time `json:"opened"`
	Closed  time.Time `json:"closed"`
	Status  string    `json:"status"` // open | closed
	By      string    `json:"by"`     // người đóng, hoặc "tự động"
	// Giữ = người đã đóng tay cảnh báo này. Lỗi còn nguyên (máy vẫn thiếu bản vá, thiết bị vẫn rớt)
	// thì KHÔNG được mở lại cảnh báo y hệt — chờ tới khi lỗi thật sự hết, lần hỏng sau mới là chuyện mới.
	Giu bool `json:"giu,omitempty"`
	// Lan = số lần thiết bị rớt lại trên CÙNG một cảnh báo, thay cho việc đẻ thêm dòng mới.
	Lan int `json:"lan,omitempty"`
}

type Command struct {
	ID      string            `json:"id"`
	Machine string            `json:"machine"`
	Type    string            `json:"type"`
	Args    map[string]string `json:"args"`
	By      string            `json:"by"`
	Created time.Time         `json:"created"`
	Status  string            `json:"status"` // pending | sent | done | failed
	Result  string            `json:"result"`
	Done    time.Time         `json:"done"`
}

type State struct {
	Accounts  []*Account  `json:"accounts"`
	Groups    []string    `json:"groups"`
	Machines  []*Machine  `json:"machines"`
	Settings  Settings    `json:"settings"`
	Alerts    []*Alert    `json:"alerts"`
	Commands  []*Command  `json:"commands"`
	Schedules []*Schedule `json:"schedules"`
	Requests  []*Request  `json:"requests"`
	Policies  []*Policy   `json:"policies"`
	// Thiết bị mạng không cài được agent (camera, máy chấm công, switch), xem devices.go.
	Devices []*NetDev   `json:"devices"`
	DevLog  []*DevEvent `json:"devlog"` // lịch sử rớt / sống lại của từng thiết bị mạng
	// Loại thiết bị cho yêu cầu hỗ trợ (Super admin tạo/xóa). Rỗng = dùng danh sách mặc định.
	DeviceTypes []string `json:"deviceTypes"`
	// Tên ô liên hệ trong form yêu cầu hỗ trợ (vd "WeChat ID"). Rỗng = "SĐT/Zalo".
	ContactLabel string `json:"contactLabel"`
	// Mật khẩu điều khiển từ xa (băm). Có đặt thì admin nhập đúng mật khẩu là vào thẳng, không cần máy đồng ý.
	RemoteSalt string `json:"remoteSalt"`
	RemoteHash string `json:"remoteHash"`
	// Mật khẩu gỡ agent (băm): người ngồi máy nhập để gỡ, không cần tài khoản quản trị. Rỗng = không ai gỡ được trên máy.
	UninstSalt string      `json:"uninstSalt"`
	UninstHash string      `json:"uninstHash"`
	UninstAt   time.Time   `json:"uninstAt"`
	UninstBy   string      `json:"uninstBy"`
	Chat       []*ChatLine `json:"chat"`
	// Các lần bật máy [bắt đầu, kết thúc] (giây unix) theo ID máy, xem uptime.go.
	Uptime map[string][][2]int64 `json:"uptime,omitempty"`
}

var defaultDeviceTypes = []string{"Máy tính", "Máy in", "Máy photo", "Máy scan", "Server", "Khác"}

// deviceTypes: gọi khi đang giữ s.mu.
func (s *Server) deviceTypes() []string {
	if len(s.st.DeviceTypes) == 0 {
		return defaultDeviceTypes
	}
	return s.st.DeviceTypes
}

// contactLabel: gọi khi đang giữ s.mu.
func (s *Server) contactLabel() string {
	if s.st.ContactLabel == "" {
		return "SĐT/Zalo"
	}
	return s.st.ContactLabel
}

type Sample struct {
	T    int64   `json:"t"`
	CPU  float32 `json:"cpu"`
	RAM  float32 `json:"ram"`
	Temp float32 `json:"temp"`
}

type Disk struct {
	Name    string  `json:"name"`
	TotalGB float64 `json:"totalGB"`
	FreeGB  float64 `json:"freeGB"`
}

type Live struct {
	CPU, RAM float64
	Temp     *float64
	Uptime   int64
	Disks    []Disk
	User     string
	Ver      string
	At       time.Time
	CPUHigh  int // số lần báo liên tiếp CPU cao
	Hist     []Sample
	lastHist time.Time
}

type Session struct {
	AccID string
	Exp   time.Time
}

type Server struct {
	mu      sync.RWMutex
	dir     string
	boot    string // thư mục -data lúc khởi động; redirect.txt nằm ở đây
	st      State
	live    map[string]*Live
	sess    map[string]*Session
	fails   map[string]*failRec
	tok     map[string]*Machine // băm token → máy
	dirty   bool
	saveBad bool // lần save gần nhất lỗi (ổ đầy, file bị khóa...): đã ghi log + mở cảnh báo máy chủ
	db      *sql.DB
	rows    map[string]rowVal // nội dung từng dòng trong mam.db ở lần ghi gần nhất, để save() chỉ ghi phần đổi
	auditMu sync.Mutex
	blobs   map[string]*Blob          // dữ liệu lớn của lệnh (tiến trình, S.M.A.R.T) giữ trong RAM ít phút
	screens map[string]*ScreenSession // phiên xem/điều khiển màn hình đang diễn ra (không lưu xuống đĩa)
	scanMu  sync.Mutex
	scan    *scanJob // lượt quét tìm thiết bị mạng đang chạy nền, xem devscan.go
}

type failRec struct {
	n     int
	until time.Time
}

func defaultSettings() Settings {
	return Settings{TempC: 85, CPU: 90, DiskFreePc: 10, OfflineMin: 5}
}

func NewServer(dir string) (*Server, error) {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	s := &Server{dir: dir, boot: dir, live: map[string]*Live{}, sess: map[string]*Session{}, fails: map[string]*failRec{}, tok: map[string]*Machine{}, blobs: map[string]*Blob{}, screens: map[string]*ScreenSession{}}
	s.st.Settings = defaultSettings()
	avatarDir = filepath.Join(dir, "avatars")
	db, err := openDB(dir)
	if err != nil {
		return nil, err
	}
	s.db = db
	rows, ok, err := loadState(db, &s.st)
	if err != nil {
		db.Close()
		return nil, err
	}
	s.rows = rows
	if !ok {
		err = s.migrateJSON()
	}
	if err == nil {
		err = s.migrateAudit()
	}
	if err != nil {
		db.Close()
		return nil, err
	}
	if s.st.Settings.TempC == 0 {
		s.st.Settings = defaultSettings()
	}
	for _, m := range s.st.Machines {
		s.tok[m.TokenHash] = m
	}
	if n := s.mergeDupMachines(); n > 0 {
		log.Printf(T("Đã gộp %d bản ghi máy trùng (cùng MAC)"), n)
	}
	for _, m := range s.st.Machines {
		s.setMachineName(m, m.Name) // cảnh báo cũ còn mang tên trước khi đổi (bản ≤1.1.55): đồng bộ một lần lúc bật
	}
	s.save() // ghi ngay phần vừa gộp/đồng bộ (chỉ ghi dòng đổi), không đợi lần lưu mỗi phút
	return s, nil
}

// setMachineName đổi tên máy và tên trên mọi cảnh báo của máy đó, để danh sách cảnh báo và báo cáo
// không tách một máy thành nhiều dòng sau khi đổi tên. Gọi khi đang giữ s.mu (hoặc lúc khởi động).
func (s *Server) setMachineName(m *Machine, name string) {
	m.Name = name
	for _, a := range s.st.Alerts {
		if a.Machine == m.ID && a.Name != name {
			a.Name = name
		}
	}
}

// save ghi những bản ghi đã đổi vào mam.db trong một giao dịch. Gọi khi đang giữ s.mu.
func (s *Server) save() {
	cur, err := splitState(&s.st)
	if err == nil {
		err = writeRows(s.db, s.rows, cur)
	}
	if err != nil { // giữ s.rows cũ: lần save sau ghi lại phần chưa lưu được
		if !s.saveBad { // chỉ ghi log lần đầu, không ghi lại mỗi lần save
			log.Printf(T("Không lưu được dữ liệu vào mam.db: %v"), err)
		}
		s.saveBad = true
		s.cond(srvM, "save", "crit", true, "Không lưu được dữ liệu vào mam.db: "+err.Error())
		return
	}
	if s.saveBad {
		s.saveBad = false
		log.Print(T("Đã lưu lại được dữ liệu vào mam.db"))
		s.cond(srvM, "save", "crit", false, "")
	}
	s.rows = cur
	s.dirty = false
}

func (s *Server) backup() {
	s.mu.RLock()
	b, _ := json.Marshal(&s.st)
	d := filepath.Join(s.dir, "backup")
	s.mu.RUnlock()
	os.MkdirAll(d, 0o700)
	os.WriteFile(filepath.Join(d, "state-"+time.Now().Format("20060102-1504")+".json"), b, 0o600)
	files, _ := filepath.Glob(filepath.Join(d, "state-*.json"))
	for len(files) > 30 {
		os.Remove(files[0])
		files = files[1:]
	}
}

func rid(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func sha(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

// ---------- nhật ký thao tác: chỉ ghi thêm ----------

type AuditEntry struct {
	T      time.Time `json:"t"`
	User   string    `json:"user"`
	Name   string    `json:"name"`
	Role   string    `json:"role"`
	IP     string    `json:"ip"`
	Kind   string    `json:"kind"`
	Msg    string    `json:"msg"`
	Target string    `json:"target"`
	Sens   bool      `json:"sens"`
}

func (s *Server) audit(e AuditEntry) {
	e.T = time.Now()
	s.auditMu.Lock()
	defer s.auditMu.Unlock()
	if err := s.insertAudit(e); err != nil {
		log.Printf(T("Không ghi được nhật ký thao tác: %v"), err)
	}
}

func (s *Server) readAudit(max int) []AuditEntry {
	s.auditMu.Lock()
	defer s.auditMu.Unlock()
	q := `SELECT data FROM audit ORDER BY n`
	if max > 0 {
		q = `SELECT data FROM (SELECT n, data FROM audit ORDER BY n DESC LIMIT ` + strconv.Itoa(max) + `) ORDER BY n`
	}
	rs, err := s.db.Query(q)
	if err != nil {
		return nil
	}
	defer rs.Close()
	var out []AuditEntry
	for rs.Next() {
		var d string
		var e AuditEntry
		if rs.Scan(&d) == nil && json.Unmarshal([]byte(d), &e) == nil {
			out = append(out, e)
		}
	}
	return out
}

// mergeDupMachines gộp bản ghi máy trùng (cùng MAC) có từ bản ≤1.1.56: máy bị thu hồi rồi cài lại agent thành bản ghi
// mới, cảnh báo và lịch sử cũ nằm ở bản ghi đã thu hồi. Chuyển cảnh báo, thời gian hoạt động, chat, yêu cầu hỗ trợ,
// lỗi của máy sang bản ghi đang dùng rồi bỏ bản ghi đã thu hồi. Gọi lúc khởi động, trả số bản ghi đã gộp.
func (s *Server) mergeDupMachines() int {
	keep := map[string]*Machine{} // MAC → bản ghi đang dùng
	for _, m := range s.st.Machines {
		if !m.Revoked && m.MAC != "" {
			keep[m.MAC] = m
		}
	}
	n := 0
	out := s.st.Machines[:0]
	for _, old := range s.st.Machines {
		k := keep[old.MAC]
		if !old.Revoked || old.MAC == "" || k == nil {
			out = append(out, old)
			continue
		}
		for _, a := range s.st.Alerts {
			if a.Machine == old.ID {
				a.Machine, a.Name = k.ID, k.Name
			}
		}
		for _, c := range s.st.Chat {
			if c.Machine == old.ID {
				c.Machine = k.ID
			}
		}
		for _, q := range s.st.Requests {
			if q.Machine == old.ID {
				q.Machine = k.ID
			}
		}
		if up := s.st.Uptime[old.ID]; len(up) > 0 {
			if s.st.Uptime == nil {
				s.st.Uptime = map[string][][2]int64{}
			}
			all := append(up, s.st.Uptime[k.ID]...)
			sort.Slice(all, func(i, j int) bool { return all[i][0] < all[j][0] })
			s.st.Uptime[k.ID] = all
		}
		delete(s.st.Uptime, old.ID)
		if b, err := os.ReadFile(evFile(s.dir, old.ID)); err == nil { // lỗi của máy: nối file cũ vào file đang dùng
			if f, err := os.OpenFile(evFile(s.dir, k.ID), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600); err == nil {
				f.Write(b)
				f.Close()
				os.Remove(evFile(s.dir, old.ID))
			}
		}
		k.ThreatSeen = append(k.ThreatSeen, old.ThreatSeen...)
		delete(s.tok, old.TokenHash)
		n++
	}
	s.st.Machines = out
	return n
}
