@echo off
setlocal
rem ASCII only on purpose: the real work is done by the .ps1 next to this file.
>nul 2>&1 net session
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
cd /d "%~dp0"
echo.
echo  1 = Tieng Viet   2 = English   3 = Chinese (zhongwen)
set /p L="  Language / Ngon ngu / yuyan [1]: "
set LANGCODE=vi
if "%L%"=="2" set LANGCODE=en
if "%L%"=="3" set LANGCODE=zh
powershell -NoProfile -ExecutionPolicy Bypass -File "%ProgramFiles%\MAM Agent\MAM-Agent.ps1" -Uninstall
echo.
pause
